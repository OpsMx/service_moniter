#!/usr/bin/env python

def get_config():

    config = {
        'collection_interval': 60    # Seconds, how often to collect metric data
    }

    return config
